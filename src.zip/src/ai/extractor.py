"""
Information extraction service.
"""